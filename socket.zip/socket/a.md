# OCRonPi 
This project is about OCR in raspberry pi and text and image is stored in blockchain accross different nodes
